"""DealBot scrapers package."""
